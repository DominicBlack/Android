package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.ListFragment;

import android.app.ListActivity;
import android.icu.text.ListFormatter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends ListActivity {
    private ListView listOfCars;
    CarAdapter carAdapter;
    private EditText addNewCar;
    private Button addButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listOfCars=(ListView)findViewById(android.R.id.list);
        addNewCar=(EditText)findViewById(R.id.ed_new_car);
        addButton=(Button)findViewById(R.id.b_add_car);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = addNewCar.getText().toString();
                int img=R.drawable.car_icon;
                carAdapter.addCar(name,img);
                addNewCar.setText("");
            }
        });
        int id=R.drawable.car_icon;
        carAdapter = new CarAdapter(this);
        setListAdapter(carAdapter);
        carAdapter.addCar("Bugatti",id);
        carAdapter.addCar("Lamborghini",id);
        carAdapter.addCar("AstonMartin",id);


    }
}
