package com.example.myapplication;

public class Car {
    public String name;
    public int imageResource;
}
